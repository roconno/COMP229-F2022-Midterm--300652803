# COMP229-F2022-MidTerm Test

## Welcome to the MidTerm Project - the Faculty Informatio App

please use **`npm install`** to install project dependencies

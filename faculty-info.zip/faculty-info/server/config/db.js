module.exports = {
  //local MongoDB deployment ->
  URI: "mongodb+srv://roconno:rifqCo1Yrm1U0Yxm@cluster0.e2238ow.mongodb.net/?retryWrites=true&w=majority",
};
